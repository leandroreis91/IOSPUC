import Foundation

struct Point{
    let x : Double
    let y : Double
    func distance(from point: Point)-> Double{
        let dist = sqrt(pow(Double(self.x - point.x),2) + pow(Double(self.y - point.y),2)).roundTo(places: 2)
        return dist
    }
    // (x,y stored properties)
    // método calculo de distancia entre dois pontos
}

struct Triangule{
    enum kind{
        case equilateral
        case isosceles
        case scalene
    }
    let vertexA : Point
    let vertexB : Point
    let vertexC : Point
    var kind : kind{
        if vertexA.distance(from: vertexB) == vertexA.distance(from: vertexC) && vertexA.distance(from: vertexB) == vertexB.distance(from: vertexC){
            return Triangule.kind.equilateral
        }else if vertexA.distance(from: vertexB) == vertexA.distance(from: vertexC) ||     vertexA.distance(from: vertexB) == vertexB.distance(from: vertexC) ||
            vertexA.distance(from: vertexC) == vertexB.distance(from: vertexC) {
            return Triangule.kind.isosceles
        }else{
            return Triangule.kind.scalene
            
        }
        //calcula distancia entre pontos AB, AC e BC
        //compara o tamanho dos lados
        //retorna o tipo .
    }
    //(vertx1, vertx2, vertx3) stored properties
    //kind -> Enumarador(equilateral, isosceles, scalene)
    
}

extension Double {
    func roundTo(places: Int) ->Double{
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded()/divisor
}
}
    
    var pontoA1 = Point(x: 2, y: 7)
    var pontoB1 = Point(x: 2, y: 3)
    var pontoC1 = Point(x: 5, y: 3)
    
    var pontoA2 = Point(x: 2, y: 3)
    var pontoB2 = Point(x: 2, y: 1)
    var pontoC2 = Point(x: 4, y: 1)
    
    var pontoA3 = Point(x: 5, y: 7)
    var pontoB3 = Point(x: 10, y: 9)
    var pontoC3 = Point(x: 5.768, y: 12.33)
    
    var triangulo1 = Triangule(vertexA: pontoA2, vertexB: pontoB2, vertexC: pontoC2)
    print(triangulo1.kind)
    
    //A(2,7), B(2,3), C(5,3))
    //A(2,3), B(2,1), C(4,1))
    //A(5,7), B(10,9), C(5.768,12.33))
