//
//  ViewController.swift
//  Todo
//
//  Created by user151698 on 4/4/19.
//  Copyright © 2019 user151698. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    struct Todo{
        var task:String
        var isCompleted:Bool = false
        
        init(task: String){
            self.task = task
            self.isCompleted = false
        }
    }
    
    
    @IBOutlet weak var tableView: UITableView!
    var itens: [Todo] = [
        Todo(task: "Terminar Exercicios de IOS"),
        Todo(task: "Comprar um Android"),
        Todo(task: "Destruir o IOS")
    ]
    	
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(TodoItemCell.self, forCellReuseIdentifier: "myCell")
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itens.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as? TodoItemCell else { fatalError() }
        cell.textLabel?.text = itens[indexPath.row].task
        cell.isCompleted = itens[indexPath.row].isCompleted
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        itens[indexPath.row].isCompleted = itens[indexPath.row].isCompleted ? false : true
        
        tableView.reloadRows(at: [indexPath], with: .fade)
        
        print("Seleção do item \(itens[indexPath.row].isCompleted)")
    }
    
    func tableView(_ _tableView:UITableView,trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) ->
        UISwipeActionsConfiguration? {
            let removeAction = UIContextualAction(
                style : .destructive,
                title: "Remover",
                handler: {(action, view, completionHandler) in
                    //remover item da lista
                    completionHandler(true)
            }
            )
            
            let swipeConfiguration = UISwipeActionsConfiguration(actions :[removeAction])
            return swipeConfiguration
            
            
    }
    
    
    func tableView(_ _tableView:UITableView,leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) ->
        UISwipeActionsConfiguration? {
            let removeAction = UIContextualAction(
                style : .normal,
                title: "Relizada",
                handler: {(action, view, completionHandler) in
                    //remover item da lista
                    completionHandler(true)
            }
            )
            
            let swipeConfiguration = UISwipeActionsConfiguration(actions :[removeAction])
            return swipeConfiguration
            
            
    }
}

