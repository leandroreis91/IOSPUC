//
//  ViewController.swift
//  Todo
//
//  Created by user151698 on 4/4/19.
//  Copyright © 2019 user151698. All rights reserved.
//

import UIKit

struct Todo : Codable{
    var task:String
    var isCompleted:Bool = false
    var id: Int?
    
    init(task: String){
        self.task = task
        self.isCompleted = false
    }
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
/*
     
     curl -X "POST" "https://puc-dam-todolist.herokuapp.com/token" \ -H 'Content-Type: application/json; charset=utf-8' \ -d $'{"user": "LA212", "password": “LA212"}'
     
    {
    "token": "ewwdEqy3xA165cOlPJfXnrTX0DXBlyMYnKN1kmGgXgA=",
    "id": 28,
    "userId": 11
    }
 */
    
    
    @IBOutlet weak var tableView: UITableView!
    var itens: [Todo] = []
    let todoRepository = TodoRepository(network: NetworkService(baseUrl: "https://puc-dam-todolist.herokuapp.com"), token: "qjmXqm+ZnDv5gneOWrMpRfP0fXh5SzrEqtjBwxU4qHQ=")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.register(TodoItemCell.self, forCellReuseIdentifier: "myCell")
        todoRepository.all{ (result) in
            switch result{
            case .success(let todos):
                self.itens = todos
                self.tableView.reloadData()
            case .error:
                print("Erro na hora de buscar")
                self.itens.removeAll(keepingCapacity: false)
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itens.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as? TodoItemCell else { fatalError() }
        cell.textLabel?.text = itens[indexPath.row].task
        cell.isCompleted = itens[indexPath.row].isCompleted
        return cell
    }
    
    func tableView(_ _tableView:UITableView,trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) ->
        UISwipeActionsConfiguration? {
            let removeAction = UIContextualAction(
                style : .destructive,
                title: "Remover",
                handler: {(action, view, completionHandler) in
                    //remover item da lista
                    self.todoRepository.delete(id: self.itens[indexPath.row].id!) { (result) in
                        switch result{
                        case .success:
                            self.itens.remove(at: indexPath.row)
                            self.tableView.reloadData()
                        case .error:
                            self.itens.removeAll(keepingCapacity: false)
                        }
                        
                        completionHandler(true)
                    }
                    completionHandler(true)
            }
            )
            
            let swipeConfiguration = UISwipeActionsConfiguration(actions :[removeAction])
            return swipeConfiguration
            
            
    }
    
    func tableView(_ _tableView:UITableView,leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) ->
        UISwipeActionsConfiguration? {
            let removeAction = UIContextualAction(
                style : .normal,
                title: "Realizada",
                handler: {(action, view, completionHandler) in
                    //Concluir item da lista
                    self.todoRepository.toggleComplete(id: self.itens[indexPath.row].id!, callback: { (result) in
                        switch result{
                        case .success(let itemTemp):
                            self.itens.remove(at: indexPath.row)
                            self.itens.insert(itemTemp, at: indexPath.row)
                            self.tableView.reloadRows(at: [indexPath], with: .top)
                        case .error:
                            self.itens.removeAll(keepingCapacity: false)
                        }
                    })
                    
                    completionHandler(true)
            }
            )
            
            let swipeConfiguration = UISwipeActionsConfiguration(actions :[removeAction])
            return swipeConfiguration
            
            
    }
    
    @IBAction func adicionarItem(_ sender: Any) {
        let alertController = UIAlertController(title: "Nova tarefa", message: "Digite a nova tarefa", preferredStyle: .alert)
        
        alertController.addTextField {
            (textField) in textField.placeholder = "Tarefa"
        }
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: {
            _ in guard let task = alertController.textFields?.first?.text else { return }
            print(task)
            self.todoRepository.create(taskTitle: task, callback: { (result) in
                switch result{
                case .success(let itemTemp):
                    print(itemTemp)
                    self.itens.append(itemTemp)
                    self.tableView.reloadData()
                case .error:
                    print("Erro no insert")
                    self.itens.removeAll(keepingCapacity: false)
                }
            })
        })
        
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
        
    }
    
}

