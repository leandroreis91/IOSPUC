//
//  ViewController.swift
//  Todo
//
//  Created by user151698 on 4/4/19.
//  Copyright © 2019 user151698. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    struct Todo{
        var task:String
        var isCompleted:Bool = false
        
        init(task: String){
            self.task = task
            self.isCompleted = false
        }
    }
    
    
    @IBOutlet weak var tableView: UITableView!
    var itens: [Todo] = [
        Todo(task: "Terminar Exercicios de IOS"),
        Todo(task: "Comprar um Android"),
        Todo(task: "Destruir o IOS")
    ]
    	
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(TodoItemCell.self, forCellReuseIdentifier: "myCell")
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itens.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as? TodoItemCell else { fatalError() }
        cell.textLabel?.text = itens[indexPath.row].task
        cell.isCompleted = itens[indexPath.row].isCompleted
        return cell
    }
    
    /*
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        itens[indexPath.row].isCompleted = itens[indexPath.row].isCompleted ? false : true
        
        tableView.reloadRows(at: [indexPath], with: .fade)
        
        print("Seleção do item \(itens[indexPath.row].isCompleted)")
    }*/
    
    func tableView(_ _tableView:UITableView,trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) ->
        UISwipeActionsConfiguration? {
            let removeAction = UIContextualAction(
                style : .destructive,
                title: "Remover",
                handler: {(action, view, completionHandler) in
                    //remover item da lista
                    self.itens.remove(at: indexPath.row)
                    self.tableView.reloadData()
                    completionHandler(true)
            }
            )
            
            let swipeConfiguration = UISwipeActionsConfiguration(actions :[removeAction])
            return swipeConfiguration
            
            
    }
    
    func tableView(_ _tableView:UITableView,leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) ->
        UISwipeActionsConfiguration? {
            let removeAction = UIContextualAction(
                style : .normal,
                title: "Realizada",
                handler: {(action, view, completionHandler) in
                    //Concluir item da lista
                    self.itens[indexPath.row].isCompleted = self.itens[indexPath.row].isCompleted ? false : true
                    
                    let itemTemp = self.itens[indexPath.row]
                    
                    self.itens.remove(at: indexPath.row)
                    self.itens.insert(itemTemp, at: indexPath.row)
                    self.tableView.reloadRows(at: [indexPath], with: .fade)
                    
                    completionHandler(true)
            }
            )
            
            let swipeConfiguration = UISwipeActionsConfiguration(actions :[removeAction])
            return swipeConfiguration
            
            
    }
    
    @IBAction func adicionarItem(_ sender: Any) {
        let alertController = UIAlertController(title: "Nova tarefa", message: "Digite a nova tarefa", preferredStyle: .alert)
        
        alertController.addTextField {
            (textField) in textField.placeholder = "Tarefa"
        }
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: {
            _ in guard let task = alertController.textFields?.first?.text else { return }
            
            self.itens.append(Todo(task: task))
            self.tableView.reloadData()
        })
        
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
        
    }
}

