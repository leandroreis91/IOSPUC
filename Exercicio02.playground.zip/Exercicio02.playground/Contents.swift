enum BankOperation {
    case withdrawl(value: Double)
    case deposit(from: String, value: Double)
}

protocol BankAccountProtocol{
    
    init(number: String, holder: String)
    
    var balance: Double {get}
    var statement: [BankOperation]{get}
    
    func withdrawl(value: Double) throws
    func deposit(value: Double, from account: String)
    func formattedStatement()-> String
    
    
}

public enum BankAccountError: Error{
    case insuficientFunds(currentBalance: Double)
}

class MyBank: BankAccountProtocol{
    required init(number: String, holder: String) {
        self.number = number
        self.holder = holder
        self.balance = 0.0
        self.statement = []
    }
    
    private let number: String
    private let holder: String
    private (set) var balance: Double
    private (set) var statement: [BankOperation]
    
    func withdrawl(value: Double) throws {
        if value <= balance {
            balance = balance - value
            statement.append(.withdrawl(value: value))
        }else{
            throw BankAccountError.insuficientFunds(currentBalance: balance)
        }
    }
    
    func deposit(value: Double, from account: String) {
        balance = balance + value
        statement.append(.deposit(from: account, value: value))
    }
    
    func formattedStatement() -> String {
        var texto = """
                    OPERATION    VALUE    FROM \n
                    """
        for linha in statement{
            switch linha{
              case .deposit(let from, let value):
                texto+="""
                       DEP          \(value)     \(from) \n
                       """
               
            case .withdrawl(let value):
                texto+="""
                       WDT          \(value) \n
                       """
            }
            
        }
        
        return texto
    }
    
}
var teste: MyBank = MyBank.init(number: "123", holder: "leandro")
teste.deposit(value: 10.0, from: "6668")
do{
    try teste.withdrawl(value: 50)
    print("Saque efetuado com sucesso!")
}catch(BankAccountError.insuficientFunds(let balance)){
    print("Saldo Insuficiente. Seu saldo é \(balance)")
}

print(teste.formattedStatement())

